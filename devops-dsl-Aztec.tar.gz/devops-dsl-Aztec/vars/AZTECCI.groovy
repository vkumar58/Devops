import groovy.sql.Sql
import java.text.SimpleDateFormat
import hudson.tasks.test.AbstractTestResultAction
import hudson.model.Actionable

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def applicationName = config.applicationName ?: 'SAMPLE'
    def buildNode = config.buildNode ?: ''
    def mvnGoals = config.mvnGoals ?: 'clean install'
    def npmGoals = config.npmGoals ?: 'install'
    def pomFileLocation = config.pomFileLocation ?: 'pom.xml'
    def packageJSONLocation = config.packageJSONLocation ?: 'package.json'
    def javaOpts = config.javaOpts ?: '-Xms2048m -Xmx4092m -XX:-UseGCOverheadLimit'
    def settingsFile = '613141442/apphazardsettingsfile.git'
    def componentCategory = config.componentCategory ?: ''
    def appGroupID = ''

    def mavenPodName = config.mavenPodName ?: 'robt-maven-npm'
    def npmPodName   = config.npmPodName ?: 'nodephantomv12'
    def sonarPodName = config.sonarPodName ?: 'sonar'
    def nexusIQPodName = config.nexusIQPodName ?: 'nexus-iq'
    def nexusPodName = config.nexusPodName ?: 'nexus'

    def executeSonar = config.executeSonar ?: 'YES'
    def sonarExclusionsPath = config.sonarExclusionsPath ?: ''

    //Coverage and UnitTest reports parameters
    def executeUnitTest = config.executeUnitTest ?: 'NO'
    def junitReportLocation = config.junitReportLocation ?: 'target/surefire-reports/*.xml'
    def jacocoClassPattern = config.jacocoClassPattern ?: '**/classes'
    def jacocoExecPattern = config.jacocoExecPattern ?: '**/**.exec'
    def jacocoSourceInclusionPattern = config.jacocoSourceInclusionPattern ?: '**/*.java'
    def jacocoSourcePattern = config.jacocoSourcePattern ?: '**/src/main/java'
    def coverageExclusions = config.coverageExclusions ?: ''
    def coverageReportFormat = config.coverageReportFormat ?: 'jacoco.xml'

    def branch = ''
    def appVersion = ''
    def deployVersion = ''
    def appPomGroupID = ''
    def appName = '' //pom.artifactId
    def artefactType = ''
    def commitID = ''
    def pipelineStage = ''
    def commiterName = ''
    def totalCommitsOfUser = ''
    def totalCommitsInBranch = ''
    def dateFormat = new SimpleDateFormat("yyyyMMddHHmm")
    def gitDateFomat = new SimpleDateFormat("yyyy-MM-dd")
    def gitCurrentDate = gitDateFomat.format(new Date())
    def date = dateFormat.format(new Date())
    def devAppVersion = ''

    def executeNexusIQ = config.executeNexusIQ ?: 'YES'
    def affectedComponentCount = 'NULL'
    def reportHTMLURL = 'NULL'
    def criticalComponentCount = '0'
    def policyViolation = 'NO'
    def criticalComponentCountLimit = '100'
    def deviatedViolationsList = ''

    def totalUnitTests = '0'
    def totalPassedUnitTests = '0'
    def totalSkippedUnitTests = '0'
    def totalFailedUnitTests = '0'

    def nexusUpload = config.nexusUpload ?: 'NO'
    def nexusUploadWithMavenGoal = config.nexusUploadWithMavenGoal ?: 'NO'
    def nexusUploadWithoutMavenGoal = config.nexusUploadWithoutMavenGoal ?: 'NO'
    def nexusUploadURL = ''
    def NexusSnapshotRepo= config.nexusSnapshotRepo?: ''
    def NexusReleaseRepo = config.nexusReleaseRepo?: ''
    def artifact_Version = ''
    def artifactId = ''
    def packageType = config.packageType ?: ''
    def nexusRepoId = ''

    def executeDeployment = config.executeDeployment ?: 'NO'
    def environmentToDeploy = config.environmentToDeploy
    def additionalLibs = config.additionalLibs ?: ''
    def YMLRepoURL = config.YMLRepoURL ?: ''
    def configurationFiles = config.configurationFiles ?: ''
    def executeShellFilePath = config.executeShellFilePath ?: ''
    def deployDirectory = config.deployDirectory ?: ''
    def deployDirectoryBackUp = config.deployDirectoryBackUp ?: ''
    def deployUser = config.deployUser ?: ''
    def deployApproverList = config.deployApproverList ?: ''
    def deployApproverListEmail = config.deployApproverListEmail ?: ''

    def s101ReportLocation = config.s101ReportLocation ?: ''
    def structure101HeadlessConfig = config.structure101HeadlessConfig ?: ''

    def metricsDB = config.metricsDB ?: 'AZTEC'
    def cfu = config.cfu ?: 'b2e-cfu-aztec-master'
    def pipelineType = 'CI'

    def customEmailMessage = 'NONE'
    def failedStage = 'None'
    def emailRecipientsList = config.emailRecipientsList

    timestamps {
        try {
            //properties([disableConcurrentBuilds(), gitLabConnection('GitLab_ROBT_Connection')])
            node("${buildNode}") {
                currentBuild.result = 'SUCCESS'
                
                stage("Checkout source code") {
                    updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                    pipelineStage = "${STAGE_NAME}"
                    step([$class: 'WsCleanup'])
                    //git branch: 'develop', credentialsId: 'eeadrobt_cred', url: "https://gitlab.agile.nat.bt.com/EEADROBT/onm-mavenbuild.git"
                    checkout scm
                    
                    if("${componentCategory}" == "UI"){
                        packageJSON = readJSON file: "${packageJSONLocation}"
                        appVersion = packageJSON.version
                        appGroupID = config.appGroupID ?: 'com/bt/uaf/apph/api'
                    } else {
                        pom = readMavenPom file: "${pomFileLocation}"
                        appVersion = pom.version
                        appPomGroupID = pom.groupId
                        appGroupID = appPomGroupID.toString().replace('.', '/')
                        appName = pom.artifactId
                    }
                    //sonarExclusionsPath = ("${sonarExclusionsPath}" == "") ? pom.properties["sonar.exclusions"] : sonarExclusionsPath

                    branch = "${BRANCH_NAME}"
                    commitID = sh(returnStdout: true, script: 'git rev-parse --short HEAD').trim()
                    commiterName = sh(returnStdout: true, script: 'git show --format="<%aE>" HEAD | head -1').trim().toString().replace('<', '').replace('>', '').trim()
                    totalCommitsOfUser = sh(returnStdout: true, script: "git shortlog -s -n -e --all --no-merges | grep -i ${commiterName} | sed -e 's/ //g' | cut -f 1 | head -1").trim()
                    totalCommitsInBranch = sh(returnStdout: true, script: 'git rev-list --count HEAD').trim()

                    updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                }

                stage("Build") {
                    updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                    pipelineStage = "${STAGE_NAME}"
                    if("${componentCategory}" == "UI"){
                        npm	{
                            npmGoal = "install --unsafe-perm &&  npm install --unsafe-perm @angular/cli -g && ${npmGoals} " // && ng test --watch=false --browsers=PhantomJS --codeCoverage=true "
        					appName = "${applicationName}"
        					npmPod  = "${npmPodName}"
    			    	}
                    }else{

                        maven {
                            mavenGoals = "${mvnGoals}"
                            branchName = "${branch}"
                            pomLocation = "${pomFileLocation}"
                            mavenPod = "${mavenPodName}"
                            applicationName =  config.applicationName
                            javaOpts   =  '"'+"${javaOpts}"+'"'
                        }
                    }

                    if ("${executeUnitTest}" == 'YES' && "${componentCategory}" == 'WS') {
                        junit "${junitReportLocation}"
                        AbstractTestResultAction testResultAction = currentBuild.rawBuild.getAction(AbstractTestResultAction.class)

                        if (testResultAction != null) {
                            totalUnitTests = testResultAction.getTotalCount()
                            totalFailedUnitTests = testResultAction.getFailCount()
                            totalSkippedUnitTests = testResultAction.getSkipCount()
                            totalPassedUnitTests = totalUnitTests - totalFailedUnitTests - totalSkippedUnitTests
                        } else {
                            echo "No Unit tests found"
                        }
                    }

                    updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                } //End of Maven build stage

                if ("${executeUnitTest}" == 'YES' && "${componentCategory}" == 'WS') {
                    stage("Unit Tests and Coverage") {
                        updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                        pipelineStage = "${STAGE_NAME}"

                        CoverageReports {
                            junitResultLocation = "${junitReportLocation}"
                            classPattern = "${jacocoClassPattern}"
                            execPattern = "${jacocoExecPattern}"
                            sourceInclusionPattern = "${jacocoSourceInclusionPattern}"
                            sourcePattern = "${jacocoSourcePattern}"
                        }

                        HTMLPublisher {
                            reportDir = config.reportDir
                            reportFiles = config.reportFiles
                            reportName = config.reportName
                        }
                        
                        updateGitlabCommitStatus name: STAGE_NAME, state: 'success'

                    } //End of Unit Tests and Coverage stage
                } //End of If Branch check for report publish
              /*  if ("${executeutplsql}"=='NO') {
                    stage("UTPLTesting"){
                        DBScript_Properties = readProperties  file: "${WORKSPACE}/utplsql.properties"
                		def sqldir = DBScript_Properties['utplscriptsdir']
                           		
                		deployApproverListEmail = DBScript_Properties['deployApproverListEmail'] 
                		deployApproverList= DBScript_Properties['deployApproverList']
                		
                		def deployApproverListEmails = "${deployApproverListEmail}"
						DBmanualApprovalEmailNotification {
							deploymentEnv = "${envDeploy}"
							EnvApprovers = "${deployApproverListEmails}"
							branchName = "${branch}"
						}
                
						echo "Approvers: ${deployApproverListEmail} ${deployApproverList}"
						timeout(time: 1, unit: 'HOURS') {
						input id: 'UserInput', message: "${mailMsg}", ok: 'Deploy', submitter: "${deployApproverList}"
						}
						
                //  		DBHostName = DBScript_Properties["${environmentToDeploy}_dbHost"]
                //  		DBServerPort = DBScript_Properties["${environmentToDeploy}_dbPort"] 
                //  		DBServiceName = DBScript_Properties["${environmentToDeploy}_dbServiceName"]
                		
                		def dbScriptsFile = readFile "${WORKSPACE}/utplscriptsorder.csv" 
                		def lines = dbScriptsFile.readLines() 
                		def index = 0;
                        for (line in lines) {  
                		    String[] scriptDetails = line.split(',')
                            DBScriptPath=scriptDetails[0].trim()
                            DBApplyScript=scriptDetails[1].trim()
    						DBApplyUser=scriptDetails[2].trim()
    						DBApplyPwd= scriptDetails[3].trim()
    							
                            try 
                            {
                                AZTEC_DB_Pipeline {
                                    dbsqldir = "${sqldir}"
                                    dbscript = "${DBApplyScript}"
                                    dbuser = "${DBApplyUser}"
                                    dbenv = "${envDeploy}"
                                    dbpwd = "${DBApplyPwd}"
                                    dbscriptpath = "${DBScriptPath}"
                             
                                    // dbHostName = "${DBHostName}"
                                    // dbHostPort = "${DBServerPort}"
                                    // dbServiceName = "${DBServiceName}"
                                }
                            } catch (Exception err) {
								echo "error in utpl testcase: ${DBApplyScript} "
								echo "error details: ${err}"
							}
                        } // for loop closing braces
                         updateGitlabCommitStatus name: STAGE_NAME, state: 'success'

                } //stage closing braces
                } */ // end of if loop
        
                if ("${executeSonar}" == 'YES') {
                    stage("Sonar Scan") {
                        updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                        pipelineStage = "${STAGE_NAME}"

                        sonarscan {
                            applicationName = config.applicationName
                            sonarPod = "${sonarPodName}"
                            projectName = config.sonarProjectName
                            projectKey = config.sonarProjectKey
                            projectVersion = config.sonarProjectVersion
                            sonarLanguage = config.sonarProjectLanguage
                            sonarSources = config.sonarSources
                            sonarBinaries = config.sonarBinaries
                            JacococoverageReportsPath = config.sonarCoverageReportsPath
                            sonarExclusions = "${sonarExclusionsPath}"
                            buildBranchName = "${branch}"
                            coverageExclusionsLocation = "${coverageExclusions}"
                            s101ReportDir = "${s101ReportLocation}"
                            s101HeadlessConfig = "${structure101HeadlessConfig}"
                            coverageReportFormat = "${coverageReportFormat}"
                        }

                        updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                    } //End of Sonarscan stage

                    stage("Sonar Quality gate Check") {
                        updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                        pipelineStage = "${STAGE_NAME}"

                        try {
                            timeout(time: 1, unit: 'HOURS') {
                                def qualityGate = waitForQualityGate()
                                if (qualityGate.status != 'OK') {
                                    error "Pipeline aborted due to quality gate failure: ${qualityGate.status}"
                                }
                            }  //End of timeout
                        } catch (Exception err) {
                            error "Failing build From jenkins in sonarqulaity gate evaluation ${err}"
                        }

                        updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                    } //End of QualityGate check stage
                } //End of sonarExecution evaluation IF statement

                if("${executeNexusIQ}" == 'YES' || ("${branch}" =~ 'Mobius_Dry_run') || ("${branch}" =~ 'master') || ("${branch}" =~ 'develop') || ("${branch}" =~ 'development') ){
                    
                    if ("${executeNexusIQ}" == 'YES') {
                        stage('NexusIQ Scan') {
                            updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                            pipelineStage = "${STAGE_NAME}"
                            nexusIQAppName = config.nexusAppName
                            packagePath_nexusIQ = config.packagePath
                            nexusIQJSONInfo = nexusPolicyEvaluation advancedProperties: '', failBuildOnNetworkError: false,
                                    iqApplication: selectedApplication("${nexusIQAppName}"),
                                    iqScanPatterns: [[scanPattern: "${packagePath_nexusIQ}"]],
                                    iqStage: 'build', jobCredentialsId: 'eeadrobt_cred'
                            criticalComponentCount = "${nexusIQJSONInfo.criticalComponentCount}"

                            manager.build.@result = (("${pipelineStage}" == 'NexusIQ Scan') && ("${currentBuild.result}" == 'UNSTABLE')) ? hudson.model.Result.SUCCESS : manager.build.@result
                            updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                        }

                        stage('NexusIQ SecurityGate') {
                            updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                            pipelineStage = "${STAGE_NAME}"

                            criticalComponentCount = "${nexusIQJSONInfo.criticalComponentCount}"
                            moderateComponentCount = "${nexusIQJSONInfo.moderateComponentCount}"
                            affectedComponentCount = "${nexusIQJSONInfo.affectedComponentCount}"
                            severeComponentCount = "${nexusIQJSONInfo.severeComponentCount}"
                            reportHTMLURL = "${nexusIQJSONInfo.applicationCompositionReportUrl}"

                            if (criticalComponentCount.toInteger() > criticalComponentCountLimit.toInteger()) {
                                policyViolation = 'YES'
                                currentBuild.result = 'FAILURE'
                                error "Build failed because of Nexus Policy Evaluation..!"
                            }

                            updateGitlabCommitStatus name: STAGE_NAME, state: 'success'
                        }   //End of nexusIQ gate stage
                    } //End of if condition
                    
                    if ("${nexusUpload}" == 'YES') {
                        stage('Upload to Nexus') {
                            updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                            pipelineStage = "${STAGE_NAME}"

                            echo "appVersion: ${appVersion}"
                            echo "appGroupID: ${appGroupID}"
                                
                            if(("${branch}" =~ 'master') || ("${branch}" =~ 'Hotfix-R'))    nexusRepoId = "${NexusSnapshotRepo}"
                            else if(("${branch}" =~ 'release') || ("${branch}" =~ 'develop'))   nexusRepoId = "${NexusReleaseRepo}"
                            else nexusRepoId = "${NexusSnapshotRepo}"
                            if(("${branch}" ==~ "master") || ("${branch}" ==~ "^HotFix\$")) {
                                artifact_Version = "${appVersion}"+'-'+"${date}"+'-SNAPSHOT'
                				artefactType = 'snapshots'
                				echo "${artifact_Version}"
                				
                			}else{
                			    artifact_Version = "${appVersion}"+'-'+"${date}"+'-SNAPSHOT'
                				artefactType = 'releases'
                				echo "${artifact_Version}"
                				
                			}
                			echo "testing before nexus upload"
                            echo "repo in upload: ${nexusRepoId}"
                			artifactUpload{
                    			nexusRepositoryId = "${nexusRepoId}"
                    			artifactPath = config.packagePath
                    			artifactID = "${applicationName}"
                    			groupID = "${appGroupID}"
                    			artifactVersion = "${artifact_Version}"
                    			packagingType = config.packageType
                    			credentialID = 'eeadrobt_cred'
                    			emailRecipients = "${emailRecipientsList}"
                    		}
                    		echo "testing after nexus upload"
                    	/*	if("${isConfigFiles}"=='YES'){
                        		artifactUpload{
                        			nexusRepositoryId = "${nexusRepoId}"
                        			artifactPath = '/target/Package/*.tar.gz.cfg'
                        			artifactID = "${applicationName}"
                        			groupID = "${appGroupID}"
                        			artifactVersion = "${artifact_Version}"
                        			packagingType = 'tar.gz.cfg'//"${packageType}"
                        			credentialID = 'eeadrobt_cred'
                        			emailRecipients = "${emailRecipientsList}"
                        		}
                        		artifactUpload{
                        			nexusRepositoryId = "${nexusRepoId}"
                        			artifactPath = '/target/Package/*.tar.gz.cfg.path'
                        			artifactID = "${applicationName}"
                        			groupID = "${appGroupID}"
                        			artifactVersion = "${artifact_Version}"
                        			packagingType = 'tar.gz.cfg.path'//"${packageType}"
                        			credentialID = 'eeadrobt_cred'
                        			emailRecipients = "${emailRecipientsList}"
                        		}
                    		}*/
                        } //End of upload nexus
                    } //End of excute if condition
                } //end of branching if condition

                /*
                if("${executeDeployment}" == 'YES' && (("${branch}" ==~ "Mobius_Dry_run") || ("${branch}" ==~ "APIGEE_POC") || ("${branch}" ==~ "master") ||  ("${branch}" ==~ "develop") || ("${branch}" ==~ "development"))){
                    stage('Trigger CD') {

                        updateGitlabCommitStatus name: STAGE_NAME, state: 'running'
                        pipelineStage = "${STAGE_NAME}"
                        def manualCD='NO'

                        build job: 'AppHazard/apphDeployment', wait: false,
                                parameters: [[$class: 'StringParameterValue', name: 'applicationName', value: "${applicationName}"],
                                             [$class: 'StringParameterValue', name: 'branchName', value: "${branch}"],
                                             [$class: 'StringParameterValue', name: 'groupId', value: "${appGroupID}"],
                                             [$class: 'StringParameterValue', name: 'appVersion', value: "${appVersion}"],
                                             [$class: 'StringParameterValue', name: 'artefactExtentionType', value: "${packageType}"],
                                             [$class: 'StringParameterValue', name: 'componentCategory', value: "${componentCategory}"],
                                             [$class: 'StringParameterValue', name: 'environmentToDeploy', value: "${environmentToDeploy}"],
                                             //[$class: 'StringParameterValue', name: 'artefactId', value: "${artifactId}"],
                                             [$class: 'StringParameterValue', name: 'deploymentDirectory', value: "${deployDirectory}"],
                                             [$class: 'StringParameterValue', name: 'deployDirectoryBackUp', value: "${deployDirectoryBackUp}"],
                                             [$class: 'StringParameterValue', name: 'deployUser', value: "${deployUser}"],
                                             [$class: 'StringParameterValue', name: 'artefactType', value: "${artefactType}"],
                                             [$class: 'StringParameterValue', name: 'deployApproverList', value: "${deployApproverList}"],
                                             [$class: 'StringParameterValue', name: 'deployApproverListEmail', value: "${deployApproverListEmail}"],
                                             [$class: 'StringParameterValue', name: 'manualCD', value: "${manualCD}"]]
                    }
                }
                */            
            }  //node end
        } catch (Exception err) {
            failedStage = "${pipelineStage}"
            updateGitlabCommitStatus name: "${pipelineStage}", state: 'failed'
            currentBuild.result = 'FAILURE'

            echo "Build failed at ${pipelineStage} with Error ${err} "
            echo 'Build failed, We should sound the Devops team...!'

        } finally {
           
                stage("Email Notification") {
                    def buildresult = "${currentBuild.result}"
                    buildStatusEmail {
                        buildResult = "${buildresult}"
                        failedStageName = "${failedStage}"
                        emailRecipients = "${emailRecipientsList}"
                        affectedComponentCount_NQ = "${affectedComponentCount}"
                        reportHtmlUrl_NQ = "${reportHTMLURL}"
                        criticalPolicyViolationCount_NQ = "${criticalComponentCount}"
                        policyViolation_NQ = "${policyViolation}"
                        DeviatedViolations_Added = "${deviatedViolationsList}"
                        customMessage = "${customEmailMessage}"
                        application = "${applicationName}"
                        branchName = "${branch}"
                    }
                } //End of Email notifications block
                
                    stage('Publish metrics') {
                    def influxDB = "${metricsDB}"
                    def jenkinsMeasurementName = 'jenkins_' + config.applicationName
                    def sonarMeasurementName = 'sonar_' + config.applicationName
                    def cred = 'influx_Cred_Metrics'
                    pipelineType = "CI"
                    cfu = 'b2e-cfu-aztec-master'
                    
                    build job: 'Metrics/metricsCI', wait: false, parameters: [
                            [$class: 'StringParameterValue', name: 'jobName', value: "${JOB_NAME}"],
                            [$class: 'StringParameterValue', name: 'totalCommitsInBranch', value: "${totalCommitsInBranch}"],
                            [$class: 'StringParameterValue', name: 'sonarKey', value: config.sonarProjectKey],
                            [$class: 'StringParameterValue', name: 'jobNumber', value: "${BUILD_NUMBER}"],
                            [$class: 'StringParameterValue', name: 'influxDB', value: influxDB],
                            [$class: 'StringParameterValue', name: 'criticalPolicyViolationCount', value: "${criticalComponentCount}"],
                            [$class: 'StringParameterValue', name: 'totalUnitTests', value: "${totalUnitTests}"],
                            [$class: 'StringParameterValue', name: 'totalPassedUnitTests', value: "${totalPassedUnitTests}"],
                            [$class: 'StringParameterValue', name: 'totalFailedUnitTests', value: "${totalFailedUnitTests}"],
                            [$class: 'StringParameterValue', name: 'commiterName', value: "${commiterName}"],
                            [$class: 'StringParameterValue', name: 'totalCommitsOfUser', value: "${totalCommitsOfUser}"],
                            [$class: 'StringParameterValue', name: 'jenkinsMeasurementName', value: "${jenkinsMeasurementName}"],
                            [$class: 'StringParameterValue', name: 'sonarMeasurementName', value: "${sonarMeasurementName}"],
                            [$class: 'StringParameterValue', name: 'cfu', value: "${cfu}"],
                            [$class: 'StringParameterValue', name: 'metricsType', value: "${pipelineType}"],
                            [$class: 'StringParameterValue', name: 'componentName', value: "${applicationName}"],
                            [$class: 'StringParameterValue', name: 'branchName', value: "${branch}"]]
                } //Publish metrics stage closure
        } //End of finally block
    } //end of timestamp
}