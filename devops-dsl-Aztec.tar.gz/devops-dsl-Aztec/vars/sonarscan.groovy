def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def applicationName = config.applicationName
    def sonarPod = config.sonarPod ?: 'sonar'
    def projectName = config.projectName
    def projectKey = config.projectKey
    def projectVersion = config.projectVersion
    def sonarLanguage = config.sonarLanguage
    def sonarSources = config.sonarSources
    def sonarBinaries = config.sonarBinaries
    def sonarInclusions = config.sonarInclusions ?: '.'
    def sonarExclusions = config.sonarExclusions ?: ''
    def sonarscanner = tool 'sonar-scanner-s101'
    def sonarSourceEncoding = config.sourceEncoding ?: 'UTF-8'

    def coverageExclusions = config.coverageExclusionsLocation ?: ''
    def coverageReportsPath = config.JacococoverageReportsPath ?: 'target/jacoco.xml'
    def structure101Reportdir = config.s101ReportDir ?: ''
    def structure101HeadlessConfig = config.s101HeadlessConfig ?: ''
    def coverageReportFormat = config.coverageReportFormat ?: 'jacoco.xml'

    def sonarCoverageformat = ''
    def sonarBranchName = config.buildBranchName
    def UIReport_Path = config.UIReportPath ?: ''
    def junitResultLocation = config.sureFireReportLocation ?: 'target/surefire-reports'

    container("${sonarPod}") {
        withSonarQubeEnv('Sonarqube-Server-Prod') {
            if ("${coverageReportFormat}" == 'jacoco.exec') {
                sonarCoverageformat = '-Dsonar.jacoco.reportPath'
            } else {
                sonarCoverageformat = '-Dsonar.coverage.jacoco.xmlReportPaths'
            }
            // If you have configured more than one global server connection, you can specify its name
            sh """
                        npm install -g typescript@latest
                        npm install typescript@latest
                        java -version                        
                        ${sonarscanner}/bin/sonar-scanner -Dsonar.projectKey=${projectKey} \
                                                          -Dsonar.projectName=${projectName} \
                                                          -Dsonar.projectVersion=${projectVersion} \
                                                          -Dsonar.sources=${sonarSources} \
                                                          -Dsonar.exclusions=${sonarExclusions} \
                                                          -Dsonar.language=${sonarLanguage} \
                                                          -Dsonar.java.binaries=${sonarBinaries} \
                                                          -Dsonar.branch.name=${sonarBranchName} \
                                                          -Dsonar.sourceEncoding=${sonarSourceEncoding} \
                                                          -Dsonar.sonar.coverage.exclusions=${coverageExclusions} \
                                                          ${sonarCoverageformat}=${coverageReportsPath}\
                                                          -Dsonar.c.file.suffixes=- \
                                                          -Dsonar.cpp.file.suffixes=- \
                                                          -Dsonar.objc.file.suffixes=- \
                                                          -Dsonar.typescript.lcov.reportPaths=${UIReport_Path} \
                                                          -Dsonar.junit.reportPaths=${junitResultLocation} \
                                                          -Dsonar.surefire.reportPaths=${junitResultLocation} 
             """
        }
        // Will use for future 
        // -Dsonar.structure101.reportdir=${structure101Reportdir} \
        // -Dsonar.structure101.java.headless.config=${structure101HeadlessConfig} \
        // -Dsonar.structure101.java.disabled=false \
    }
}
