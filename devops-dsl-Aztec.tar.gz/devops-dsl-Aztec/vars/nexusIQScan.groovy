def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    def nexusApplication = config.nexusAppName
    def nexusURL = 'https://agile.nat.bt.com/iqserver'
    def nexusIQPod = config.nexusIQPod ?: 'nexus-iq'
    def packageLocation = config.packagePath
    def nexusIQResponseJsonFile = config.nexusiqResponseJsonFile ?: 'nexusIQ_response.json'

    container("${nexusIQPod}") {
        sh """
        java -jar /tools/NexusIQ_CLI/nexus-iq-cli-1.75.0-01.jar -i ${nexusApplication} -r ${nexusIQResponseJsonFile} -s ${nexusURL} -a ${user}:${pass} ${packageLocation}
        cat ${nexusIQResponseJsonFile}
	"""
    }
}
