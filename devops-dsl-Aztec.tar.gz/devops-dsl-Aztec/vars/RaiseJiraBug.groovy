def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    def peojectKey = config.peojectKey
    def issueID = config.issueID
    def jiraSite = config.jiraSite ?: 'JIRA'
    def failedStage = config.failedAtStage
    wrap([$class: 'BuildUser']) {
                GET_BUILD_USER_ID = sh(script: 'echo "${BUILD_USER_ID}"', returnStdout: true).trim()
            }
    echo "${GET_BUILD_USER_ID}"
    def testIssue = [fields: [project    : [key: "${peojectKey}"],
                              summary    : "New JIRA bug Created for ${failedStage} failure",
                              description: "New JIRA bug created from Jenkins for ${failedStage} failure for build ${BUILD_URL}",
                              issuetype  : [id: "${issueID}"]]]
    response = jiraNewIssue issue: testIssue, site: "${jiraSite}"
    echo response.successful.toString()
    echo response.data.key.toString()
    // Will use for future
    // jiraAssignIssue failOnError: false, idOrKey: response.data.key.toString(), site: 'JIRA', userName: "${GET_BUILD_USER_ID}"
}
