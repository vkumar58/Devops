def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    def deploymentRepoName = config.deploymentRepoName
    def playbookFilePath = config.playbookFilePath
    def inventoryFileName = config.inventoryFileName
    def deploymentRepoPath = config.deploymentRepoPath
    def applicationName = config.applicationName
    def app_version = config.artifactVersion
    def app_groupID = config.groupID
    def app_artifactId = config.artifactId
    def artifactFormats = config.artifactFormats
    def nexusArtifactURL = config.nexusArtifactURL
    def deployDirectory = config.deploymentDirectory
    def deploymentFile = config.applicationName
    def additionalFileRepo = config.additionFileRepo
    def configFileRepoURL = config.configFileRepoURL
    def configurationFiles = config.configFiles
    def additionalLibraryFile = config.additionalLibrary
    def branchName = config.branchName
    def executeShellFilePath = config.executeShellFilePath
    def componentCategory = config.componentCategory

    echo "config file values: ${config}"
    echo "in ansible.groovy"

    withCredentials([usernamePassword(credentialsId: 'EEADROBT_Credentials', passwordVariable: 'pass', usernameVariable: 'user')]) {
                echo "app_version: ${app_version}"
                echo "app_Name:  ${applicationName}"
                echo "app_groupID: ${app_groupID}"
                echo "artifact_URL: ${nexusArtifactURL}"
                echo "nexususername: ${user}"
                echo "nexuspassword: ${pass}"
                echo "deployDirectory: ${deployDirectory}"
                echo "deploymentFile: ${applicationName}"
                echo "configFileRepo: ${configFileRepoURL}"
                echo "configurationFile: ${configurationFiles}"
                echo "additionalFile: ${additionalLibraryFile}"
                echo "branch_Name: ${branchName}"
                echo "ExecuteShellFilePath: ${executeShellFilePath}"
                echo "componentCategory: ${componentCategory}"

                ansibleTower(async: false, credential: 'EEADROBT-creds', extraVars: """
---
app_version: "${app_version}"
app_Name: "${applicationName}"
app_groupID: "${app_groupID}"
artifact_URL: "${nexusArtifactURL}"
nexususername: "${user}"
nexuspassword: "${pass}"
deployDirectory: "${deployDirectory}"
deploymentFile: "${applicationName}"
configFileRepo: "${configFileRepoURL}"
configurationFile: "${configurationFiles}"
additionalFile: "${additionalLibraryFile}"
branch_Name: "${branchName}"
ExecuteShellFilePath: "${executeShellFilePath}"

""",
                        importTowerLogs: true, importWorkflowChildLogs: false, inventory: '', jobTags: '', jobTemplate: "ngautofix_${componentCategory}", jobType: 'run', limit: '', removeColor: true, scmBranch: '', skipJobTags: '', templateType: 'job', throwExceptionWhenFail: true, towerCredentialsId: 'tower_cred', towerServer: 'ansible-tower', verbose: false)

            }
}
