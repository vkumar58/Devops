@Library(['devops-dsl@AppHazardPROD']) _

def buildNode = 'Ansible'
def pipelineStage = 'NONE'

def sanityTotalTests = '0'
def sanityPassedTests = '0'
def sanityFailedTests = '0'
def e2eTotalTests = '0'
def e2ePassedTests = '0'
def e2eFailedTests = '0'
def citDeploymentStageName = 'citDeployment'
def devDeploymentStageName = 'devDeployment'
def e2eDeploymentStageName = 'e2eDeployment'
def prodDeploymentStageName = 'prodDeployment'
def preprodDeploymentStageName = 'preprodDeployment'

def envStage = ''
def failedStage = 'None'
def buildresult = ""
def envSpringProfile = ''

def applications = "${applicationName}"
def envDeploy = "${environmentToDeploy}"
def deployApprove ="${deployApproverListEmail}"
def branch = "${branchName}"
def pipelineType = 'CD'
def ansibleTemplate = "aztec_${componentCategory}"

timestamps {
    try {
        node("${buildNode}") {
            currentBuild.result = 'SUCCESS'
            currentBuild.displayName = "#${BUILD_NUMBER} | ${applicationName} | ${environmentToDeploy} "
            currentBuild.description = "${componentCategory} | ${branchName} | ${appVersion}"
            

            ansibleTemplate =  ("${environmentToDeploy}" == 'prod' && "${componentCategory}"=='API' ) ? "aztec_${componentCategory}_${environmentToDeploy}" : "aztec_${componentCategory}"            

            stage("${environmentToDeploy}Deployment") {
                
                pipelineStage = "${STAGE_NAME}"

                def repositoryId = "APP12781_AZTEC"
                def artefactList = ''
                def artefactLimit = "6";
                def artefactTypeSelected = "${artefactType}"
                def artifactGroupId = "${groupId}".toString().replace('/', '.')
                def nexusURLFromAPI = ''
                def mailMsg = "Is Deployment to ${environmentToDeploy} environemnt OK to proceed"
                
                // artificact limit to find the nexus artifact url
                artefactLimit= ("${manualCD}" == 'YES') ? '6' : '1'

                withCredentials([usernamePassword(credentialsId: 'eeadrobt_cred', passwordVariable: 'pass', usernameVariable: 'user')]) {
                    artefactList = sh returnStdout: true,
                    script: """curl -sS -u '${user}':'${pass}' 'https://agile.nat.bt.com/nexus/service/rest/v1/search/assets?repository=${repositoryId}_maven_${artefactTypeSelected}&group=${artifactGroupId}&name=${applicationName}&maven.extension=${artefactExtentionType}&sort=version&direction=desc&maven.classifier=' """

                    def mydata = readJSON text: artefactList;
                    def i = 1
                    def choice = []
                    for (datapoint in mydata['items']) {
                        if (i <= "${artefactLimit}".toInteger()) {
                            choice.add(datapoint['downloadUrl'])
                            i = i + 1
                        } else {
                            break;
                        }
                    }
                    
                    if ("${manualCD}" == "NO") {
                        nexusURLFromAPI = "${choice[0]}"
                    } else {
                        def USER_INPUT = input(message: "Select one artefact", submitter: "${deployApproverList}", submitterParameter: 'approver_name',
                                parameters: [
                                        [$class     : 'ChoiceParameterDefinition',
                                         choices    : choice.join('\n'),
                                         name       : 'input',
                                         description: "Select Yes to Continue with selected artefact"]
                                ])
                        nexusURLFromAPI = USER_INPUT['input']
                        
                        print(USER_INPUT['input'])
                        echo "approver is "
                        print(USER_INPUT['approver_name'])
                    }
                    echo "artifactURL: ${nexusURLFromAPI}" //It is for knowing which artifact it is picking for the deployment
                    manualApprovalEmailNotification {
                        deploymentEnv = "${envDeploy}"
                        EnvApprovers = "${deployApprove}"
                        branchName = "${branch}"
                        application = "${applications}"
                    }
                    
                    echo "Approvers: ${deployApproverListEmail}"
                    timeout(time: 1, unit: 'HOURS') {
                        input id: 'UserInput', message: "${mailMsg}", ok: 'Deploy', submitter: "${deployApproverList}"
                    }

ansibleTower(async: false, credential: '', extraVars: """
---
appVersion: "${appVersion}"
appName: "${applicationName}"
appGroupId: "${artifactGroupId}"
artifact_URL: "${nexusURLFromAPI}"
nexususername: "${user}"
nexuspassword: "${pass}"
deployDirectory: "${deploymentDirectory}"
backUpDirectory: "${deployDirectoryBackUp}"
deployUser: "${deployUser}"
branchName: "${branchName}"
deployEnv: "${environmentToDeploy}" 
hostServerName: "${environmentToDeploy}servers_${componentCategory}"
artifactFormat: "${artefactExtentionType}"
""",

importTowerLogs: true, importWorkflowChildLogs: false, inventory: '', jobTags: '', jobTemplate: "${ansibleTemplate}",
jobType: 'run', limit: '', removeColor: true, scmBranch: '', skipJobTags: '', templateType: 'job', throwExceptionWhenFail: true,
towerCredentialsId: 'tower_cred', towerServer: 'ansible-tower', verbose: false )
                }
            }
        }
    } catch (Exception err) {
        echo "Error caught${err}"
        failedStage = "${pipelineStage}"
        currentBuild.result = 'FAILURE'
    } finally {
        stage("Email Notification for CD") {
            buildresult = "${currentBuild.result}"
            echo "${applicationName}"
            buildStatusEmail {
                buildResult = "${buildresult}"
                emailRecipients = "${deployApprove}"
                failedStageName = "${failedStage}"
                deploymentFrom = "CD"
                application = "${applications}"
                branchName = "${branch}"
                //pipelineType = "${pipelineType}"
            }
        } // End of Email notifications block
        
    	stage('Publish metrics'){
    	  def influxDB ='Aztec' //"${metricsDB}"
    	  def cred = 'influx_Cred_Metrics'
    	  def jenkinsMeasurementName = "jenkins_${applicationName}"
    	  
    	  def cfu = 'b2e-cfu-aztec-master-3'
          pipelineType = 'CD'
        	  build job: 'Metrics/metricsCD', wait: false, parameters:
        	                                                [[$class: 'StringParameterValue', name: 'sanityTotalTests', value: "${sanityTotalTests}"], 
                                                            [$class: 'StringParameterValue', name: 'sanityPassedTests', value: "${sanityPassedTests}"], 
                                                            [$class: 'StringParameterValue', name: 'sanityFailedTests', value: "${sanityFailedTests}"], 
                                                            [$class: 'StringParameterValue', name: 'jobName', value: "${JOB_NAME}"],
                                                            [$class: 'StringParameterValue', name: 'jobNumber', value: "${BUILD_NUMBER}"], 
                                                            [$class: 'StringParameterValue', name: 'influxDB', value: "${influxDB}"],
                                                            [$class: 'StringParameterValue', name: 'e2eTotalTests', value: "${e2eTotalTests}"],
                                                            [$class: 'StringParameterValue', name: 'e2ePassedTests', value: "${e2ePassedTests}"],
                                                            [$class: 'StringParameterValue', name: 'e2eFailedTests', value: "${e2eFailedTests}"],
                                                            [$class: 'StringParameterValue', name: 'jenkinsMeasurementName', value: "${jenkinsMeasurementName}"],
                                                            [$class: 'StringParameterValue', name: 'devDeploymentStageName', value: "${devDeploymentStageName}"],
                                                            [$class: 'StringParameterValue', name: 'citDeploymentStageName', value: "${citDeploymentStageName}"],
                                                            [$class: 'StringParameterValue', name: 'e2eDeploymentStageName', value: "${e2eDeploymentStageName}"],
                                                            [$class: 'StringParameterValue', name: 'preprodDeploymentStageName', value: "${preprodDeploymentStageName}"],
                                                            [$class: 'StringParameterValue', name: 'cfu', value: "${cfu}"],
                                                            [$class: 'StringParameterValue', name: 'metricsType', value: "${pipelineType}"],
                                                            [$class: 'StringParameterValue', name: 'branchName', value: "${branch}"],
                                                            [$class: 'StringParameterValue', name: 'prodDeploymentStageName', value: "${prodDeploymentStageName}"],
                                                            [$class: 'StringParameterValue', name: 'componentName', value: "${applicationName}"]]
    
        }
    } // End of finally block
}
