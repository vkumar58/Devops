def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    def mavenGoals = config.mavenGoals
    def branchName = config.branchName
    def mavenPod = config.mavenPod
    def appName =  config.applicationName
    def pomLocationName = config.pomLocation
    def maven_opts = config.mavenOpts ?: '"' + '-Xms256m -Xmx1024m -Xss1024k' + '"'
    def java_opts = config.javaOpts ?: '"' + '-Xms1024m -Xmx1024m -XX:-UseGCOverheadLimit' + '"'
    def GET_BUILD_USER = 'NONE'
    wrap([$class: 'BuildUser']) {
        GET_BUILD_USER = sh(script: 'echo "${BUILD_USER}"', returnStdout: true).trim()
    }

    container("${mavenPod}") {
        sh """
                   whoami
                   export MAVEN_OPTS=${maven_opts}
                   export NODE_OPTIONS=--max-old-space-size=9000
                   export JAVA_OPTS=${java_opts}
                   mvn  -s ${WORKSPACE}/settings.xml ${mavenGoals} -f ${WORKSPACE}/${pomLocationName}
                   ls -la
                   
        """
         
       /* if("${appName}" == 'AZTEC_EEB_ONM_AutoD'){
            sh """
                   ls -la
                   ls -la target/
                   ls -la target/Package
                   ls -la target/Config
                   cd ${WORKSPACE}
                   mkdir Package
                   cp target/Package/*.tar.gz Package
                   cp target/Config/*.tar.gz.cfg Package
                   cp target/Config/*.tar.gz.cfg.path Package
    ls LOCAL_DB
            """
        } else{
            sh """
                   ls -la
                   ls -la target/
                   ls -la target/Package
                   ls -la target/Config
                   cd ${WORKSPACE}
                   mkdir Package
                   cp target/Package/*.tar.gz Package
        """
        }
         if ("${appName}" == 'AZTEC_EEB_BILLBACKUP_GENERATION_PROCESS'){
            sh """
                   ls -la
                   ls -la target/
                   ls -la target/Package
                   ls -la target/Config
                   cd ${WORKSPACE}
                   mkdir Package
                   cp target/Package/*.tar.gz Package
            """
        }else if ("${appName}" == 'AZTEC_EEB_Invoice_Generation'){ 
            */
         
        
    }
}
