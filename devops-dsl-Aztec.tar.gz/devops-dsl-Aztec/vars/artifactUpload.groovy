def call(body) {
	def config = [:]
	body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
	
	def nexusRepositoryId = config.nexusRepositoryId
	def filePath = config.artifactPath
	def artifactID = config.artifactID
	def groupID = config.groupID
	def artifactVersion = config.artifactVersion
	def packagingType = config.packagingType
	def credentialID = config.credentialID
	
	echo "${config}"
	withCredentials([usernamePassword(credentialsId: "${credentialID}", passwordVariable: 'nexus_password', usernameVariable: 'nexus_username')]) {
		def artifactURL = "https://agile.nat.bt.com/nexus/repository/${nexusRepositoryId}/${groupID}/${artifactID}/${artifactVersion}/${artifactID}-${artifactVersion}.${packagingType}"
		def packageVersion = "${artifactVersion}"
		def returnStatus_info = sh(returnStdout: true, script: "curl -o /dev/null -I -w '%{http_code}' -v -u ${nexus_username}:${nexus_password} --upload-file ${WORKSPACE}/${filePath}  https://agile.nat.bt.com/nexus/repository/${nexusRepositoryId}/${groupID}/${artifactID}/${artifactVersion}/${artifactID}-${artifactVersion}.${packagingType}").trim()
		echo "${returnStatus_info}"
        if ((returnStatus_info.toInteger() == 400) || (returnStatus_info.toInteger() == 404)) {
        	echo "Artifact already exists"
        	artifactUploadFailureStatus {
            	uploadurl = "${artifactURL}"
            	uploadVersion = "${packageVersion}"
            	emailrecipientslist = config.emailRecipients
            	applicationNameInfo = "${artifactID}"
			       statusInfo_upload = "${returnStatus_info}"
        	}
        	error "Artifact Upload issue, Please check email Notification for failure reason."
        }	
	} // With credentials block end
}
