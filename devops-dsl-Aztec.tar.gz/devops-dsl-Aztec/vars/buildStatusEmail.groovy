def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def buildResult = config.buildResult
    def emailRecipients = config.emailRecipients
    def affectedComponentCount_NexusIQ = config.affectedComponentCount_NQ ?: 'NULL'
    def reportHtmlUrl_NexusIQ = config.reportHtmlUrl_NQ ?: 'NULL'
    def criticalPolicyViolationComponentCount_NexusIQ = config.criticalPolicyViolationCount_NQ ?: 'NULL'
    def policyViolation_NexusIQ = config.policyViolation_NQ ?: 'NO'
    def failedStageName = config.failedStageName
    def replyEmailId = 'devops.coe@bt.com'
    def DeviatedViolations_Added = config.DeviatedViolations_Added
    def customMessage_email = config.customMessage?:'NONE'
    def deployment_From = config.deploymentFrom?: "CI"
    def branch = config.branchName
    def applicationName = config.application
    //def pipelineType = config.pipelineType

    if (("${customMessage_email}" != "NONE")) {
        customMessage_email = 'Note: ' + "${customMessage_email}"
    } else {
        customMessage_email = ''
    }
    if ("${policyViolation_NexusIQ}" == 'YES') {
        // Will be use for future
        // def testIssue = [fields: [ // 4 or key must present for project.
        // project: [key: 'EED'],
        // summary: "Jenkins: ${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult} with Security Vulnerabilities",
        // description: "Jenkins: ${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult} with Security Vulnerabilities",
        // id or name must present for issueType.
        // issuetype: [id: '10100']]]
        // response = jiraNewIssue issue: testIssue, site: 'JIRA'
        // echo response.successful.toString()
        // echo response.data.toString()

        mail(
                body: "Hi AppHazard Team,\n\nApplication : ${applicationName}\n\nEnvironment/Branch : ${branch}\n\n${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult}.\nYou can find build log at ${BUILD_URL}\nThere are new security vulnerabilities identified, deviated from Baseline Vulnerabilities.\n\nTotal Violations details are: \n affectedComponentCount: ${affectedComponentCount_NexusIQ}\ncriticalPolicyViolationComponentCount: ${criticalPolicyViolationComponentCount_NexusIQ}\nreportHtmlUrl: ${reportHtmlUrl_NexusIQ}\nPlease check Nexus IQ Vulnerability report.\n\n${customMessage_email}\n\nRegards,\nDevops CoE Team",
                replyTo: "${replyEmailId}",
                subject: "Mobius Prod | AppHazard | ${applicationName} | ${branch} | #${BUILD_NUMBER} is ${buildResult}",
                to: "${emailRecipients}"
        )
    } else if ("${failedStageName}" == 'None' && "${deployment_From}" == "CI") {
        mail(
                body: "Hi AppHazard Team,\n\nApplication : ${applicationName}\n\nEnvironment/Branch : ${branch}\n\n${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult}.\nYou can find build log at ${BUILD_URL}\n\n CriticalPolicyViolation: ${criticalPolicyViolationComponentCount_NexusIQ}\n AffectedComponentCount: ${affectedComponentCount_NexusIQ}\n ReportHTMLUrl: ${reportHtmlUrl_NexusIQ} \n${customMessage_email}\n\nRegards,\nDevops CoE Team",
                replyTo: "${replyEmailId}",
                subject: "Mobius Prod | AppHazard | ${applicationName} | ${branch} | #${BUILD_NUMBER} is ${buildResult}",
                to: "${emailRecipients}"
        )
    } else if ("${failedStageName}" == 'None' && "${deployment_From}" == "CD") {
        mail(
                body: "Hi AppHazard Team,\n\nApplication : ${applicationName}\n\nEnvironment/Branch : ${branch}\n\n${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult}.\nYou can find build log at ${BUILD_URL}\n\n ${customMessage_email}\n\nRegards,\nDevops CoE Team",
                replyTo: "${replyEmailId}",
                subject: "Mobius Prod | AppHazard | ${applicationName} | ${branch} | #${BUILD_NUMBER} is ${buildResult}",
                to: "${emailRecipients}"
        )
    }
    else {
        mail(
                body: "Hi AppHazard Team,\n\nApplication : ${applicationName}\n\nEnvironment/Branch : ${branch}\n\n${JOB_NAME} job with build number #${BUILD_NUMBER} is ${buildResult} at stage ${failedStageName}.\nYou can find build log at ${BUILD_URL}\n${customMessage_email}\n\nRegards,\nDevops CoE Team",
                replyTo: "${replyEmailId}",
                subject: "Mobius Prod | AppHazard | ${applicationName} | ${branch} | #${BUILD_NUMBER} is ${buildResult} at stage ${failedStageName}",
                to: "${emailRecipients}"
        )
    }
}
