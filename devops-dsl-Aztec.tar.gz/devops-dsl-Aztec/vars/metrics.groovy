def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    node('shared_metrics') {
        def componentName = "${componentName}"
        currentBuild.displayName = "#${BUILD_NUMBER} | ${componentName} "
        currentBuild.description = "${branchName}"

        stage('Metrics extraction and Publish') {
            checkout scm
            withCredentials([usernamePassword(credentialsId: 'EEADROBT_credential', passwordVariable: 'CI_password', usernameVariable: 'CI_username'), usernamePassword(credentialsId: 'sonarAdminCred', passwordVariable: 'sonarPassword', usernameVariable: 'sonarUsername'), usernamePassword(credentialsId: 'influx_Cred_Metrics', passwordVariable: 'influxdb_password', usernameVariable: 'influxdb_username')]) {
                sh """
            			sleep 5
        				if [ ${metricsType} == 'CI' ]; 
        				then
        				pip3 list
        				python3 ${WORKSPACE}/influx_script.py https://mobius.nat.bt.com/${cfu}/blue/rest/organizations/jenkins/pipelines/${jobName}/runs/${jobNumber}/ ${sonarKey} ${influxDB} ${totalCommitsInBranch} ${influxdb_username} ${influxdb_password} ${CI_username} ${CI_password} ${criticalPolicyViolationCount} ${sonarUsername} ${sonarPassword} ${totalUnitTests} ${totalPassedUnitTests} ${totalFailedUnitTests} ${commiterName} ${totalCommitsOfUser} ${jenkinsMeasurementName} ${sonarMeasurementName} ${SONAR_URL_EE} ${affectedComponentCount} ${severeComponentCount} ${moderateComponentCount}
        				else
        				echo "inside else"
        				python3 ${WORKSPACE}/influx_script_CD.py https://mobius.nat.bt.com/${cfu}/blue/rest/organizations/jenkins/pipelines/${jobName}/runs/${jobNumber}/ ${influxDB} ${influxdb_username} ${influxdb_password} ${CI_username} ${CI_password} ${sanityTotalTests} ${sanityPassedTests} ${sanityFailedTests} ${e2eTotalTests} ${e2ePassedTests} ${e2eFailedTests} ${jenkinsMeasurementName} ${devDeploymentStageName} ${e2eDeploymentStageName} ${branchName} ${citDeploymentStageName} ${liveDeploymentStageName}
        				fi
        			"""
            }
        }
    }
}
