def call(body) {
	def config = [:]
	body.resolveStrategy = Closure.DELEGATE_FIRST
	body.delegate = config
	body()

	def Approvers = config.EnvApprovers ?: 'yuvaraju.g@bt.combb'
	def deploymentEnvironment = config.deploymentEnv
	def branch = config.branchName
	def applicationName = config.application
	echo "sending email to ${Approvers} ${applicationName} ${branch}"
	mail(
			body: "Hi AppHazard Deployment approvers,\n\nApplication : ${applicationName}\n\nEnvironment/Branch : ${branch}\n\n${JOB_NAME} job with build number #${BUILD_NUMBER} is Waiting for your approval for Deployment into ${deploymentEnvironment} environment.\nYou can Approve/Reject the build at ${BUILD_URL}\n\nRegards,\nDevops CoE Team",
			replyTo: 'threkashri.pt@bt.com',
			subject: "Mobius Prod | AppHazard | ${applicationName} | ${branch} | #${BUILD_NUMBER} is Waiting for approval",
			to: "${Approvers}"
	)
}
