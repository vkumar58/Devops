def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    def dockerBuildImageName = config.dockerImageName
    def pomLocationName = config.pomLocation
    def credentialID = config.credentialID
    def branchName = config.branchName
    echo "${branchName}"
    withCredentials([usernamePassword(credentialsId: "${credentialID}", passwordVariable: 'nexus_password', usernameVariable: 'nexus_username')]) {
        docker.image("${dockerBuildImageName}").inside("-v /app/maven:/app/maven --net=host") {
            sh """
           		    git branch
           		    git config --global user.email "devopscoe@bt.com"
           		    git config --global user.name "devopscoe"
           		    git checkout -b ${branchName} origin/${branchName}
           		    git branch
           	    	mvn --batch-mode -f ${WORKSPACE}/${pomLocationName} -Dusername=${nexus_username} -Dpassword=${nexus_password} -DpreparationGoals=verify  -Darguments="-Dmaven.test.skip=true" release:prepare -s ${WORKSPACE}/settings.xml 
           	        mvn --batch-mode -f ${WORKSPACE}/${pomLocationName} -Dusername=${nexus_username} -Dpassword=${nexus_password} -Darguments="-Dmaven.test.skip=true" release:perform -s ${WORKSPACE}/settings.xml
            	"""
        }
    }
}
