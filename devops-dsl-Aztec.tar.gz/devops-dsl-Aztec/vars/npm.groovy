def call(body)
{
	def config = [:]
	body.resolveStrategy = Closure.DELEGATE_FIRST
    	body.delegate = config
    	body()
    	def applicationName = config.appName
		def goals = config.npmGoal
		def npmPod = config.npmPod
		echo "${config}"
		container("${npmPod}") {
		            sh """
    		            cd ${WORKSPACE}
    		            pwd
    		            npm ${goals}
    		            ls -la
    		            mkdir target
    		            ls -la dist/app-hazard-ui
    		            zip -r target/apph-ui.zip dist/app-hazard-ui/* .htaccess
		            """
		 }
}	
  