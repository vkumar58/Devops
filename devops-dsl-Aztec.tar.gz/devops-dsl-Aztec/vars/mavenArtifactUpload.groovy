def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    
    def nexusRepositoryId = config.nexusRepositoryId
    def filePath = config.artifactPath
    def artifactID = config.artifactID
    def groupID = config.groupID
    def artifactVersion = config.artifactVersion
    def packagingType = config.packagingType
    def credentialID = config.credentialID
    withCredentials([usernamePassword(credentialsId: "${credentialID}", passwordVariable: 'nexus_password', usernameVariable: 'nexus_username')]) {
                sh """
		 curl -v -u ${nexus_username}:${nexus_password} --upload-file ${WORKSPACE}/${filePath}  https://agile.nat.bt.com/nexus/repository/${nexusRepositoryId}/${groupID}/${artifactID}/${artifactVersion}/${artifactID}-${artifactVersion}.${packagingType}
		"""
            }
}
